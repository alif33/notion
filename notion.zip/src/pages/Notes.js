import Layout from '../components/Layout';

function Notes() {
  return (
    <Layout>
        <div className="col-md-10 container-center">
          <h3 className="text-center">Select a note, or create a new one.</h3>
        </div>
    </Layout>
  );
}

export default Notes;